package com.saapsidi.game

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLoginPage()
    }

    private fun showLoginPage() {

        val mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.gravity = Gravity.CENTER
        mainLayout.setPadding(40, 40, 40, 40)
        mainLayout.setBackgroundColor(Color.WHITE)

        val title = TextView(this)
        title.text = "🎲 SAAP SIDI"
        title.textSize = 32f
        title.setTypeface(null, Typeface.BOLD)
        title.gravity = Gravity.CENTER

        val subtitle = TextView(this)
        subtitle.text = "Play • Compete • Win"
        subtitle.textSize = 18f
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(0, 10, 0, 40)

        val mobileInput = EditText(this)
        mobileInput.hint = "Enter Mobile Number"
        mobileInput.textSize = 18f
        mobileInput.inputType =
            android.text.InputType.TYPE_CLASS_PHONE

        val loginButton = Button(this)
        loginButton.text = "LOGIN / CONTINUE"
        loginButton.textSize = 18f

        val registerText = TextView(this)
        registerText.text = "New player? Register here"
        registerText.textSize = 16f
        registerText.gravity = Gravity.CENTER
        registerText.setPadding(0, 30, 0, 0)

        mainLayout.addView(
            title,
            LinearLayout.LayoutParams(
                -1,
                -2
            )
        )

        mainLayout.addView(
            subtitle,
            LinearLayout.LayoutParams(
                -1,
                -2
            )
        )

        mainLayout.addView(
            mobileInput,
            LinearLayout.LayoutParams(
                -1,
                65
            )
        )

        mainLayout.addView(
            loginButton,
            LinearLayout.LayoutParams(
                -1,
                65
            ).apply {
                topMargin = 25
            }
        )

        mainLayout.addView(
            registerText,
            LinearLayout.LayoutParams(
                -1,
                -2
            )
        )

        loginButton.setOnClickListener {

            val mobile = mobileInput.text.toString().trim()

            if (mobile.length < 10) {
                Toast.makeText(
                    this,
                    "Enter valid mobile number",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                showHomePage()
            }
        }

        registerText.setOnClickListener {
            Toast.makeText(
                this,
                "Registration coming soon",
                Toast.LENGTH_SHORT
            ).show()
        }

        setContentView(mainLayout)
    }

    private fun showHomePage() {

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        layout.setPadding(30, 30, 30, 30)

        val title = TextView(this)
        title.text = "🎲 SAAP SIDI"
        title.textSize = 30f
        title.setTypeface(null, Typeface.BOLD)
        title.gravity = Gravity.CENTER

        val welcome = TextView(this)
        welcome.text = "Welcome Player!"
        welcome.textSize = 20f
        welcome.gravity = Gravity.CENTER
        welcome.setPadding(0, 20, 0, 40)

        val playButton = Button(this)
        playButton.text = "PLAY GAME"
        playButton.textSize = 18f

        val walletButton = Button(this)
        walletButton.text = "WALLET"
        walletButton.textSize = 18f

        val referralButton = Button(this)
        referralButton.text = "REFER & EARN"
        referralButton.textSize = 18f

        layout.addView(title)
        layout.addView(welcome)

        layout.addView(
            playButton,
            LinearLayout.LayoutParams(-1, 65)
        )

        layout.addView(
            walletButton,
            LinearLayout.LayoutParams(-1, 65).apply {
                topMargin = 15
            }
        )

        layout.addView(
            referralButton,
            LinearLayout.LayoutParams(-1, 65).apply {
                topMargin = 15
            }
        )

        playButton.setOnClickListener {
            showRoomPage()
        }

        walletButton.setOnClickListener {
            Toast.makeText(
                this,
                "Wallet coming soon",
                Toast.LENGTH_SHORT
            ).show()
        }

        referralButton.setOnClickListener {
            Toast.makeText(
                this,
                "Referral coming soon",
                Toast.LENGTH_SHORT
            ).show()
        }

        setContentView(layout)
    }

    private fun showRoomPage() {

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(25, 25, 25, 25)

        val title = TextView(this)
        title.text = "SELECT ROOM"
        title.textSize = 28f
        title.setTypeface(null, Typeface.BOLD)
        title.gravity = Gravity.CENTER
        title.setPadding(0, 10, 0, 25)

        layout.addView(title)

        for (i in 1..10) {

            val roomButton = Button(this)

            roomButton.text = "ROOM $i"
            roomButton.textSize = 17f

            layout.addView(
                roomButton,
                LinearLayout.LayoutParams(
                    -1,
                    60
                ).apply {
                    bottomMargin = 10
                }
            )

            roomButton.setOnClickListener {
                Toast.makeText(
                    this,
                    "Room $i selected",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        setContentView(layout)
    }
}